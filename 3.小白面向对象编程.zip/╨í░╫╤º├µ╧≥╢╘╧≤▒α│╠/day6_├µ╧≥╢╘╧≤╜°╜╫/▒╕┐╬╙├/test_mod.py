

def sayhi():
    print("hi from test_mod...")