


#__import__("property") # 解释器用的

import importlib

#importlib.import_module("property") #官方推荐
importlib.import_module("day3_函数编程.fib") #官方推荐

